#ifndef NOTIFICATION_H
#define NOTIFICATION_H

#ifdef __cplusplus
extern "C" {
#endif

/* prototypes for the example */
void init_notification(void);
SNMPAlarmCallback send_example_notification;


#ifdef __cplusplus
}
#endif

#endif /* NOTIFICATION_H */
