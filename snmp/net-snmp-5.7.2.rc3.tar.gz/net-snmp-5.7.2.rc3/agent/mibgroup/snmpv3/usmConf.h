#ifndef _MIBGROUP_USMCONF_H
#define _MIBGROUP_USMCONF_H

#include <net-snmp/library/snmpusm.h>
config_belongs_in(agent_module)
extern void     init_usmConf(void);

#endif  /* _MIBGROUP_USMCONF_H */
