#ifndef SNMPTLSTMSESSION_H
#define SNMPTLSTMSESSION_H

config_require(tlstm-mib/snmpTlstmSession/snmpTlstmSession)

#endif /* SNMPTLSTMSESSION_H */
